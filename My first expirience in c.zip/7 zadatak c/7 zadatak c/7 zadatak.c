#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
int maksimum(int broj1, int broj2);
int main() {
    int broj1, broj2;
    printf("Unesite prvi broj: ");
    if (scanf("%d", &broj1) != 1) {
        printf("Greska pri unosu prvog broja.\n");
        return 1;
    }
    printf("Unesite drugi broj: ");
    if (scanf("%d", &broj2) != 1) {
        printf("Greska pri unosu drugog broja.\n");
        return 1;
    }
    int rezultat = maksimum(broj1, broj2);
    printf("Maksimum: %d\n", rezultat);

    return 0;
}
int maksimum(int broj1, int broj2) {
    if (broj1 > broj2) {
        return broj1;
    }
    else {
        return broj2;
    }
}

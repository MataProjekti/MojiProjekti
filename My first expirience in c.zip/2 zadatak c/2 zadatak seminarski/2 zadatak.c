#include <stdio.h>

void ispisi_broj(int broj) {
    printf("Broj: %d\n", broj);
}
int main() {
    ispisi_broj(10);
    ispisi_broj(20);
    ispisi_broj(30);

    return 0;
}

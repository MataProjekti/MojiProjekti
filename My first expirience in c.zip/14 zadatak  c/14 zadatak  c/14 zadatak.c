#include <stdio.h>
void ispis(int niz[], int brojElemenata);
int main() {
    int cb[] = { 1, 2, 3, 4, 5 };

    int brojElemenata = sizeof(cb) / sizeof(cb[0]);

    ispis(cb, brojElemenata);

    return 0;
}
void ispis(int niz[], int brojElemenata) {
    printf("Ispis niza:\n");

    for (int i = 0; i < brojElemenata; i++) {
        printf("%d ", niz[i]);
    }
    printf("\n");
}

import os
from dotenv import load_dotenv
load_dotenv()

class Config:
    SECRET_KEY = os.getenv("SECRET_KEY", "dev-secret-key-please-change")
    SQLALCHEMY_DATABASE_URI = os.getenv("DATABASE_URI", "sqlite:///arsenal_fansite.db")
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    CACHE_TYPE = "simple"
    CACHE_DEFAULT_TIMEOUT = 60 * 5
    RATE_LIMIT_PER_MIN = int(os.getenv("RATE_LIMIT_PER_MIN", "30"))
    # News API example (replace with your real news API key/endpoint if available)
    NEWS_API_ENDPOINT = os.getenv("NEWS_API_ENDPOINT", "https://newsapi.org/v2/everything")
    NEWS_API_KEY = os.getenv("NEWS_API_KEY", "")

from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, URLField
from wtforms.validators import DataRequired, Length, URL

class RegisterForm(FlaskForm):
    username = StringField("Korisničko ime", validators=[DataRequired(), Length(3, 80)])
    password = PasswordField("Lozinka", validators=[DataRequired(), Length(6, 128)])
    submit = SubmitField("Registruj se")

class LoginForm(FlaskForm):
    username = StringField("Korisničko ime", validators=[DataRequired()])
    password = PasswordField("Lozinka", validators=[DataRequired()])
    submit = SubmitField("Prijavi se")

class FavoriteForm(FlaskForm):
    title = StringField("Naslov", validators=[DataRequired(), Length(1,255)])
    url = URLField("URL", validators=[DataRequired(), URL(), Length(1,1024)])
    submit = SubmitField("Dodaj u favorite")

import os
from flask import Flask, render_template, redirect, url_for, flash, request, abort
from config import Config
from models import db, User, Favorite
from forms import RegisterForm, LoginForm, FavoriteForm
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from flask_caching import Cache
from utils import fetch_official_links, get_news, rate_limited
from datetime import datetime

def create_app():
    app = Flask(__name__, static_folder="static", template_folder="templates")
    app.config.from_object(Config)
    db.init_app(app)
    cache = Cache(app)
    login_manager = LoginManager(app)
    login_manager.login_view = "login"

    @login_manager.user_loader
    def load_user(user_id):
        return User.query.get(int(user_id))

    @app.route("/")
    def index():
        quick_links = [
            {"title": "Arsenal Official", "url": "https://www.arsenal.com"},
            {"title": "Arsenal Shop", "url": "https://shop.arsenal.com"},
            {"title": "Tickets - Arsenal", "url": "https://www.arsenal.com/tickets"}
        ]
        # news via simple cache
        news = cache.get("news_items")
        if news is None:
            news = get_news("Arsenal", page_size=5)
            cache.set("news_items", news)
        # gallery images (list files from static/images/)
        images = []
        images_dir = os.path.join(app.static_folder, "images")
        if os.path.isdir(images_dir):
            for ent in os.listdir(images_dir):
                if ent.lower().endswith((".jpg", ".jpeg", ".png", ".gif", ".webp")):
                    images.append(url_for("static", filename=f"images/{ent}"))
        return render_template("index.html", quick_links=quick_links, news=news, images=images[:6])

    @app.route("/merch")
    @cache.cached(timeout=60*5, key_prefix="merch_page")
    @rate_limited
    def merch():
        official_merch_url = "https://shop.arsenal.com"
        links = fetch_official_links(official_merch_url, selector="a")
        filtered = [l for l in links if "product" in l["url"] or "category" in l["url"] or "shop" in l["url"]]
        return render_template("merch.html", items=filtered[:30], official=official_merch_url)

    @app.route("/tickets")
    @cache.cached(timeout=60*5, key_prefix="tickets_page")
    @rate_limited
    def tickets():
        official_tickets_url = "https://www.arsenal.com/tickets"
        links = fetch_official_links(official_tickets_url, selector="a")
        filtered = [l for l in links if "ticket" in l["url"] or "tickets" in l["url"] or "fixtures" in l["url"]]
        return render_template("tickets.html", items=filtered[:30], official=official_tickets_url)

    @app.route("/news")
    def news():
        news_items = get_news("Arsenal", page_size=10)
        return render_template("news.html", items=news_items)

    @app.route("/gallery")
    def gallery():
        images = []
        images_dir = os.path.join(app.static_folder, "images")
        if os.path.isdir(images_dir):
            for ent in os.listdir(images_dir):
                if ent.lower().endswith((".jpg", ".jpeg", ".png", ".gif", ".webp")):
                    images.append(url_for("static", filename=f"images/{ent}"))
        return render_template("gallery.html", images=images)

    @app.route("/register", methods=["GET", "POST"])
    def register():
        if current_user.is_authenticated:
            return redirect(url_for("index"))
        form = RegisterForm()
        if form.validate_on_submit():
            if User.query.filter_by(username=form.username.data).first():
                flash("Korisničko ime je zauzeto", "warning")
            else:
                u = User(username=form.username.data, password_hash=generate_password_hash(form.password.data))
                db.session.add(u)
                db.session.commit()
                flash("Uspešno registrovan. Možete se prijaviti.", "success")
                return redirect(url_for("login"))
        return render_template("register.html", form=form)

    @app.route("/login", methods=["GET", "POST"])
    def login():
        if current_user.is_authenticated:
            return redirect(url_for("index"))
        form = LoginForm()
        if form.validate_on_submit():
            user = User.query.filter_by(username=form.username.data).first()
            if user and check_password_hash(user.password_hash, form.password.data):
                login_user(user)
                flash("Uspešno prijavljen", "success")
                next_page = request.args.get("next") or url_for("index")
                return redirect(next_page)
            flash("Pogrešni podaci", "danger")
        return render_template("login.html", form=form)

    @app.route("/logout")
    @login_required
    def logout():
        logout_user()
        return redirect(url_for("index"))

    @app.route("/favorites", methods=["GET", "POST"])
    @login_required
    def favorites():
        form = FavoriteForm()
        if form.validate_on_submit():
            fav = Favorite(user_id=current_user.id, title=form.title.data, url=form.url.data)
            db.session.add(fav)
            db.session.commit()
            flash("Dodato u favorite", "success")
            return redirect(url_for("favorites"))
        items = Favorite.query.filter_by(user_id=current_user.id).order_by(Favorite.created_at.desc()).all()
        return render_template("favorites.html", items=items, form=form)

    @app.route("/favorites/delete/<int:fid>", methods=["POST"])
    @login_required
    def delete_favorite(fid):
        fav = Favorite.query.get_or_404(fid)
        if fav.user_id != current_user.id:
            abort(403)
        db.session.delete(fav)
        db.session.commit()
        flash("Obrisano iz favorita", "info")
        return redirect(url_for("favorites"))

    @app.route("/admin")
    @login_required
    def admin():
        if not current_user.is_admin:
            abort(403)
        users = User.query.order_by(User.created_at.desc()).all()
        favs = Favorite.query.order_by(Favorite.created_at.desc()).limit(50).all()
        return render_template("admin.html", users=users, favorites=favs)

    @app.route("/health")
    def health():
        return {"status": "ok", "time": datetime.utcnow().isoformat()}

    return app

if __name__ == "__main__":
    app = create_app()
    with app.app_context():
        db.create_all()
        # create initial admin if not exists
        if not User.query.filter_by(username="admin").first():
            admin_user = User(username="admin", password_hash=generate_password_hash("admin123"), is_admin=True)
            db.session.add(admin_user)
            db.session.commit()
    app.run(debug=True, port=int(os.getenv("PORT", 5000)))

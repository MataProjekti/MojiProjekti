import time
import threading
from functools import wraps
from flask import request, abort
import requests
from bs4 import BeautifulSoup
from config import Config

_rate_store = {}
_lock = threading.Lock()

def rate_limited(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        ip = request.remote_addr or "unknown"
        window = 60
        now = int(time.time())
        key = f"{ip}:{func.__name__}"
        with _lock:
            times = _rate_store.get(key, [])
            times = [t for t in times if t > now - window]
            if len(times) >= Config.RATE_LIMIT_PER_MIN:
                abort(429, description="Too many requests, slow down.")
            times.append(now)
            _rate_store[key] = times
        return func(*args, **kwargs)
    return wrapper

def fetch_official_links(url, selector=None, timeout=8):
    headers = {"User-Agent": "ArsenalFanSiteBot/1.0 (+https://example.com)"}
    try:
        r = requests.get(url, headers=headers, timeout=timeout)
        r.raise_for_status()
    except Exception:
        return []
    soup = BeautifulSoup(r.text, "html.parser")
    anchors = soup.select(selector or "a")
    results = []
    seen = set()
    from urllib.parse import urljoin
    for a in anchors:
        href = a.get("href")
        text = (a.get_text() or href or "").strip()
        if not href:
            continue
        if href.startswith("/"):
            href = urljoin(url, href)
        key = (text, href)
        if key in seen:
            continue
        seen.add(key)
        results.append({"title": text, "url": href})
    return results

def get_news(query="Arsenal", page_size=5):
    """
    Basic news fetcher using NEWS_API_ENDPOINT (NewsAPI.org style).
    If no API key is provided, returns an empty list.
    You can replace with your own football/news API.
    """
    if not Config.NEWS_API_KEY:
        return []
    params = {
        "q": query,
        "apiKey": Config.NEWS_API_KEY,
        "pageSize": page_size,
        "language": "en",
        "sortBy": "publishedAt"
    }
    try:
        r = requests.get(Config.NEWS_API_ENDPOINT, params=params, timeout=8)
        r.raise_for_status()
        data = r.json()
        articles = data.get("articles", [])
        # map to smaller structure
        return [
            {"title": a.get("title"), "url": a.get("url"), "source": a.get("source", {}).get("name"), "publishedAt": a.get("publishedAt")}
            for a in articles
        ]
    except Exception:
        return []
